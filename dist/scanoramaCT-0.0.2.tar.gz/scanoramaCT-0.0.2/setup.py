import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="scanoramaCT",
    version="0.0.2",
    author="Gunsagar Gulati",
    author_email="gunsagargulati@gmail.com",
    description="An adapted version of the Scanorama package by Brian Hie, Bryan Bryson, and Bonnie Berger for application to CytoTRACE.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/gunsagargulati/CytoTRACE",
    packages=setuptools.find_packages(),
	install_requires=['annoy', 'intervaltree', 'numpy', 'scipy', 'sklearn', 'fbpca', 'matplotlib'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
